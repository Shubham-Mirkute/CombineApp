package com.example.combineapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

public class Adapter  extends RecyclerView.Adapter<Adapter.MyViewHolder> {
    String[] data1;
    int images[];
    Context context;

    public Adapter(Context  ct, String[] user_names, int[] img){
        context = ct;
        data1 =user_names;
        images= img;
    }
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recycler_row,parent,false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull  Adapter.MyViewHolder holder, int position) {
        holder.user_name.setText(data1[position]);
        holder.user_image.setImageResource(images[position]);
    }

    @Override
    public int getItemCount() {
        return images.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView user_name ;
        ImageView user_image;
        ConstraintLayout constain_main;
        public MyViewHolder(@NonNull  View itemView) {
            super(itemView);
            user_name = itemView.findViewById(R.id.user_name);
            user_image = itemView.findViewById(R.id.user_image);
            constain_main = itemView.findViewById(R.id.constain_main);
        }
    }
}
