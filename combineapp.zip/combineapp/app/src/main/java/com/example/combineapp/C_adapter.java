package com.example.combineapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

public class C_adapter extends RecyclerView.Adapter<C_adapter.MyViewHolder> {
    Context context;
    String[] data;
    String[] data2;
    String[] data3;
    String[] data4;
    int[] images;
    public C_adapter(Context ct, String[] ContactName, String[] ContactPhone, String[] ContactEmail, String[] ContactAddress, int[] img){
        context = ct;
        data=ContactName;
        data2=ContactPhone;
        data3=ContactEmail;
        data4=ContactAddress;
        images= img;
    }
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.c_tile,parent,false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull  C_adapter.MyViewHolder holder, int position) {
        holder.ContactName.setText(data[position]);

        holder.ContactImage.setImageResource(images[position]);

        holder.mainTile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context,c_details.class);
                intent.putExtra("data",data[position]);
                intent.putExtra("images",images[position]);

                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return images.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView ContactName;
        ImageView ContactImage;
        ConstraintLayout mainTile;
        public MyViewHolder(View itemView){
            super(itemView);
            ContactName = itemView.findViewById(R.id.ContactName);
            ContactImage = itemView.findViewById(R.id.ContactImage);
            mainTile = itemView.findViewById(R.id.tile);
        }
    }
}
