package com.example.combineapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class c_details extends AppCompatActivity {
    TextView AddressDetails, NumberDetails, EmailDetails, nameDetails;
    ImageButton imageDetail;
    String data;
    int images;
    String[] ContactPhone;
    String[] ContactEmail;
    String[] ContactAddress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cdetails);

        nameDetails = findViewById(R.id.nameDetails);
        NumberDetails = findViewById(R.id.NumberDetails);
        EmailDetails = findViewById(R.id.EmailDetails);
        AddressDetails = findViewById(R.id.AddressDetails);
        imageDetail = findViewById(R.id.imageDetail);


        ContactPhone = getResources().getStringArray(R.array.PhoneNumbers);
        ContactEmail = getResources().getStringArray(R.array.Mails);
        ContactAddress = getResources().getStringArray(R.array.Address);

        getData();
        setData();
    }
    protected void getData(){
        if(getIntent().hasExtra("data")&&getIntent().hasExtra("images")){
            data = getIntent().getStringExtra("data");
            images = getIntent().getIntExtra("images",1);
        }
        else {
            Toast.makeText(this,"No data",Toast.LENGTH_SHORT).show();
        }
    }

    private void setData(){
        nameDetails.setText(data);
        NumberDetails.setText(ContactPhone[0]);
        EmailDetails.setText(ContactEmail[0]);
        AddressDetails.setText(ContactAddress[0]);
        imageDetail.setImageResource(images);
    }
}