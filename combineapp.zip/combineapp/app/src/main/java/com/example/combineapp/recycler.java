package com.example.combineapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class recycler extends AppCompatActivity {
    RecyclerView recyclerview;
    String user_names[];
    int images[]={R.drawable.user,R.drawable.user_1,R.drawable.user_2,R.drawable.user_3,R.drawable.profile,R.drawable.user,R.drawable.user_image};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);

        recyclerview= findViewById(R.id.recyle);

        user_names =getResources().getStringArray(R.array.users);

        Adapter myAdapter = new Adapter(this,user_names,images);
        recyclerview.setAdapter(myAdapter);
        recyclerview.setLayoutManager(new LinearLayoutManager(this));
    }
}