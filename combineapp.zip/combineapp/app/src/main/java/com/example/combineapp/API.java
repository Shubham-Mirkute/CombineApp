package com.example.combineapp;


public class API  {
    private String date;
    private String localName;
    private String name;
    private  String countryCode;
    private  boolean fixed;
    private  boolean global;
    private String counties;
    private  int launchYear;
    private  String[] types;

    public String getCountryCode() {
        return countryCode;
    }

    public boolean isFixed() {
        return fixed;
    }

    public boolean isGlobal() {
        return global;
    }

    public String getCounties() {
        return counties;
    }

    public int getLaunchYear() {
        return launchYear;
    }

    public String[] getTypes() {
        return types;
    }

    public String getLocalName() {
        return localName;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }


}