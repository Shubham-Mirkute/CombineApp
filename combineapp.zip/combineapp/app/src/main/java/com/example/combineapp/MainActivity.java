package com.example.combineapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button api,contact,bloodbank;

        bloodbank = findViewById(R.id.bloodbank);
        contact = findViewById(R.id.contact);
        api = findViewById(R.id.api);

        bloodbank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bloodbankActivity();
            }
        });
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contactActivity();
            }
        });
        api.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                apiActivity();
            }
        });
    }
    public void bloodbankActivity(){
        Intent intent = new Intent(this, bloodbank.class);
        startActivity(intent);
    }
    public void contactActivity(){
        Intent intent = new Intent(this, contact.class);
        startActivity(intent);
    }
    public void apiActivity(){
        Intent intent = new Intent(this, apifetching.class);
        startActivity(intent);
    }
}