package com.example.combineapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class contact extends AppCompatActivity {
    RadioGroup radioGroup;
    LinearLayout linearLayout;
    RadioButton radioButton;
    ConstraintLayout HomeScreen;
    RecyclerView recycler;
    String[] ContactName;
    String[] ContactEmail;
    String[] ContactPhone;
    String[] ContactAddress;
    int[] images ={
            R.drawable.profile, R.drawable.user, R.drawable.user_2,
            R.drawable.user_1, R.drawable.user_3, R.drawable.user_image,
            R.drawable.profile, R.drawable.user_3, R.drawable.user_image,
            R.drawable.user, R.drawable.user_2, R.drawable.profile,
            R.drawable.user_3, R.drawable.user_image , R.drawable.user
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);



            radioGroup=(RadioGroup)findViewById(R.id.radioGroup);
            linearLayout= findViewById(R.id.linearLayout);
            HomeScreen= findViewById(R.id.mainscreen);
            recycler = findViewById(R.id.recycler);

            ContactName = getResources().getStringArray(R.array.Names);

            C_adapter c_adapter =new C_adapter(this,ContactName,ContactEmail,ContactPhone,ContactAddress,images);
            recycler.setAdapter(c_adapter);
            recycler.setLayoutManager(new LinearLayoutManager(this));
        }

        public void onclickbuttonMethod(View v){
            int selectedId = radioGroup.getCheckedRadioButtonId();
            radioButton = (RadioButton) findViewById(selectedId);
            if(selectedId==-1){
                Toast.makeText(contact.this,"Please select ", Toast.LENGTH_SHORT).show();
            }
            else {
                HomeScreen.setBackgroundResource(R.color.teal_700);
            }
    }
}