package com.example.combineapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class apifetching extends AppCompatActivity {
    private TextView Names ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apifetching);

        Names = findViewById(R.id.Name);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://date.nager.at/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        API_interface holidayapi = retrofit.create(API_interface.class);
        Call<List<API>> call = holidayapi.HOLIDAYS();
        call.enqueue(new Callback<List<API>>() {
            @Override
            public void onResponse(Call<List<API>> call, Response<List<API>> response) {
                if(!response.isSuccessful()){
                    Names.setText("Code: " +response.code());
                    return;
                }
                List<API> api = response.body();
                for (API API :api){

                    String DATA="";
                    DATA+= "Name: " +API.getName() + "\n";
                    DATA+= "Local Name: " +API.getLocalName() + "\n";
                    DATA+= "Date: " +API.getDate() + "\n\n\n";
                    Names.append(DATA);
                }
            }
            @Override
            public void onFailure(Call<List<API>> call, Throwable t) {
                Names.setText(t.getMessage());
            }
        });
    }
}