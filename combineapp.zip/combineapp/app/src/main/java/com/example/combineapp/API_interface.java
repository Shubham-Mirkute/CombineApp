package com.example.combineapp;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface API_interface {
    @GET("api/v3/PublicHolidays/2017/AT")
    Call<List<API>> HOLIDAYS();
}
