package com.example.combineapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {
    Button singUp;
    EditText username,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        singUp = findViewById(R.id.singUp);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);

        singUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(username.getText().toString().equals("ADMIN")&&password.getText().toString().equals("0000")){
                    String str = username.getText().toString();
                    Intent intent = new Intent(login.this,Homepage.class);
                    intent.putExtra("message_key",str);
                    startActivity(intent);
                }
                if(username.getText().toString().equals("Shubham")&&password.getText().toString().equals("0123")){

                    String str = username.getText().toString();
                    Intent intent = new Intent(login.this,recycler.class);
                    intent.putExtra("message_key",str);
                    startActivity(intent);

                }
                if(username.getText().toString().equals("rohit")&&password.getText().toString().equals("0123")){

                    String str = username.getText().toString();
                    Intent intent = new Intent(login.this,recycler.class);
                    intent.putExtra("message_key",str);
                    startActivity(intent);

                }
                if(username.getText().toString().equals("raj")&&password.getText().toString().equals("0123")){

                    String str = username.getText().toString();
                    Intent intent = new Intent(login.this,recycler.class);
                    intent.putExtra("message_key",str);
                    startActivity(intent);

                }
                if(username.getText().toString().equals("suhas")&&password.getText().toString().equals("0123")){

                    String str = username.getText().toString();
                    Intent intent = new Intent(login.this,recycler.class);
                    intent.putExtra("message_key",str);
                    startActivity(intent);

                }
                if(username.getText().toString().equals("john")&&password.getText().toString().equals("0123")){

                    String str = username.getText().toString();
                    Intent intent = new Intent(login.this,recycler.class);
                    intent.putExtra("message_key",str);
                    startActivity(intent);

                }
                else {
                    Toast.makeText(getApplicationContext(),"Please check details you submitted",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}